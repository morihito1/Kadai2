# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '965ec9fbd3823f45460185d99551208251aef00585180706bcb0d740865205b7618d45b4cffec4cc2a64857fb2a87ac2cf15ad3cb2539385af349caa2fdb67a4'